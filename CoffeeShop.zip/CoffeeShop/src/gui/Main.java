package gui;

import javax.swing.plaf.metal.MetalLookAndFeel;

import bus.StringExe;

import java.time.*;
import java.time.format.*;
import java.util.*;
import java.sql.*;
import dto.*;

import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		try { 
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel"); 
			//UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } 
        catch (Exception e) { 
            System.out.println("Look and Feel not set"); 
        } 
//		LoginFrame lg = new LoginFrame();
//		PDFreport a= new PDFreport();
//		a.BillReport("00001");
//		a.ImportReport("00003");
		try {
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/coffeehousedb","root","");
			Statement st= conn.createStatement();
			System.out.print("Nhap id:");
			String id;
			id=sc.nextLine();
			String sql="SELECT * from customer ORDER BY cus_id DESC";
			ResultSet rs=st.executeQuery(sql);
			ArrayList<Customer> arr=new ArrayList<Customer>();
			while(rs.next()) {
				Customer cus=new Customer();
				cus.setCus_id(rs.getString(1));
				cus.setCus_name(rs.getString(2));
				cus.setPhone(rs.getString(3));
				cus.setStatus(rs.getInt(4));
				arr.add(cus);
			}
			for(Customer p:arr) {
				System.out.println(p.getCus_id()+ " "+ p.getCus_name()+" "+ p.getStatus());
			}
//			Customer a= new Customer("01","abc","0123456789",0);
//			sql="insert into customer(cus_id,cus_name,phone,status) values('"+a.getCus_id()+"','"+a.getCus_name()+"','"+a.getPhone()+"','"+a.getStatus()+"')";
//			st.executeUpdate(sql);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("Done");
		
	}

}
