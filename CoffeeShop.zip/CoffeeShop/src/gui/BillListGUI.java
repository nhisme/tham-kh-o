package gui;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Point;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.table.*;

public class BillListGUI extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTable tb1 = new JTable();
	private JTable tb2 = new JTable();
	String[] header1 = {"Mã HĐ","Tên NV","Tên KH","Ngày lập","Tổng tiền","Tổng khuyến mãi"};
	String[] header2 = {"Tên SP","Số lượng","Đơn giá","Giá khuyến mãi"};
	private DefaultTableModel md1 = new DefaultTableModel(header1,0);
	private DefaultTableModel md2 = new DefaultTableModel(header2,0);

	/**
	 * Create the panel.
	 */
	public BillListGUI() {
		setPreferredSize(new Dimension(1000, 700));
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLocation(new Point(10, 10));
		panel.setBounds(new Rectangle(10, 10, 250, 700));
		panel.setBounds(10, 12, 250, 700);
		add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Th\u00F4ng tin h\u00F3a \u0111\u01A1n", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(10, 12, 230, 200);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mã hóa đơn:");
		lblNewLabel.setBounds(10, 12, 90, 20);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Mã nhân viên:");
		lblNewLabel_1.setBounds(10, 42, 90, 20);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mã khách hàng:");
		lblNewLabel_2.setBounds(10, 73, 90, 20);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Tổng tiền: ");
		lblNewLabel_3.setBounds(10, 102, 90, 20);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Ngày nhập:");
		lblNewLabel_4.setBounds(10, 132, 90, 20);
		panel_1.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(110, 12, 110, 20);
		panel_1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(110, 42, 110, 20);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(110, 72, 110, 20);
		panel_1.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(110, 102, 110, 20);
		panel_1.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(110, 132, 110, 20);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Khuyến mãi: ");
		lblNewLabel_5.setBounds(10, 162, 90, 20);
		panel_1.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(110, 162, 110, 20);
		panel_1.add(textField_5);
		textField_5.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "Chi ti\u1EBFt h\u00F3a \u0111\u01A1n", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setBounds(10, 378, 230, 137);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Mã sản phẩm:");
		lblNewLabel_6.setBounds(10, 15, 90, 20);
		panel_2.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Số lượng:");
		lblNewLabel_7.setBounds(10, 45, 90, 20);
		panel_2.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Đơn giá:");
		lblNewLabel_8.setBounds(10, 75, 90, 20);
		panel_2.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Khuyến mãi");
		lblNewLabel_9.setBounds(10, 105, 90, 20);
		panel_2.add(lblNewLabel_9);
		
		textField_6 = new JTextField();
		textField_6.setBounds(110, 15, 110, 20);
		panel_2.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(110, 45, 110, 20);
		panel_2.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(110, 75, 110, 20);
		panel_2.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBounds(110, 105, 110, 20);
		panel_2.add(textField_9);
		textField_9.setColumns(10);
		
		JButton btnNewButton = new JButton("Thêm");
		btnNewButton.setBounds(20, 223, 89, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Xóa");
		btnNewButton_1.setBounds(121, 223, 89, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Sửa");
		btnNewButton_2.setBounds(56, 257, 89, 23);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_4 = new JButton("Thêm");
		btnNewButton_4.setBounds(20, 537, 89, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Xóa");
		btnNewButton_5.setBounds(121, 537, 89, 23);
		panel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Sửa");
		btnNewButton_6.setBounds(70, 571, 89, 23);
		panel.add(btnNewButton_6);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(300, 50, 650, 400);
		add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		tb1.setModel(md1);
		JScrollPane scrollPane = new JScrollPane(tb1);
		panel_3.add(scrollPane);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(300, 460, 650, 200);
		add(panel_4);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		tb2.setModel(md2);
		JScrollPane scrollPane_1 = new JScrollPane(tb2);
		panel_4.add(scrollPane_1, BorderLayout.NORTH);

	}
}
